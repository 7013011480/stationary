package com.poc.HeirarchyPOC.entity;
import java.io.Serializable;
import java.time.ZonedDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employee")
public class Employee implements Serializable {


   @Id
   @Column(name = "employee_id")
   private Integer employeeId;

   @NotNull
   @Column(name = "employee_name")
   private String employeeName;

   @Column(name="mobile_no")
   private String mobileNo;
   
   @Column(name="designation")
   private String designation;
   
   @Column(name = "created_date")
   private ZonedDateTime createdDate; 

}
