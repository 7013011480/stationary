/**
 *
 * Copyright (c) "TCS Genomics Lab Foundation Platform Project"
 * TATA Consultancy Services [https://www.tcs.com/]
 *
 */
package com.poc.HeirarchyPOC.TCUPService.impl;

import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import com.poc.HeirarchyPOC.TCUPService.TCUPUserService;

import com.poc.HeirarchyPOC.configuration.ConstantEndpoints;
import com.poc.HeirarchyPOC.model.TCUPCatalogResponseModel;

import com.poc.HeirarchyPOC.configuration.AppConfiguration;
import com.poc.HeirarchyPOC.model.TCUPFile;

@Slf4j
@Service
public class TCUPUserServiceImpl implements TCUPUserService {

    @Autowired
    private ConstantEndpoints endpoints;

    @Autowired
    private RestTemplate restTemplate;

    /**
     * Method to get TCUP user for the provided userId and apiKey
     *
     * @param apiKey
     * @param userId
     * @return
     * @author 786070
     */
    public TCUPCatalogResponseModel getCatalogData(String apiKey,String key) {
        log.info("inside getTCUPUser service");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .scheme(endpoints.getS_scheme())
                .host(endpoints.getTcup_host())
                .path(endpoints.getTCUP_CATALOG_ENDPOINT())
                .queryParam("metadata", key)
                .queryParam("deleted", "false")
                .build();

        log.debug("getTCUPUser by id endpoint: " + uriComponents.toUriString());
        System.out.println(uriComponents.toString());
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.add("x-api-key", apiKey);

        // call TCUP API to get user by id and api
        try {
        ResponseEntity<TCUPCatalogResponseModel> response = restTemplate.exchange(
                uriComponents.toUriString(),
                HttpMethod.GET,
                new HttpEntity(headers),
                TCUPCatalogResponseModel.class);
        
        log.info("getTCUPUser by id api response status: " + response.getStatusCode().toString());
        System.out.println(response.toString());
        
        if (response.getStatusCode() == HttpStatus.OK) {
            if (response.hasBody() && response.getBody() != null) {
            	return response.getBody();
            }
        }
        }
        catch(Exception ex)
        {
        	log.error("Error while connecting to TCUP: " + ex.toString());
        }
        

        return null;
    }
}
