package com.poc.HeirarchyPOC.service;

public interface InvokeTCUPCatalogService {

}
