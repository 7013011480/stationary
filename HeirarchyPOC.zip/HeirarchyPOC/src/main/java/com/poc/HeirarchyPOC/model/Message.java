/**
 *
 * Copyright (c) "TCS Genomics Lab Foundation Platform Project"
 * TATA Consultancy Services [https://www.tcs.com/]
 *
 */
package com.poc.HeirarchyPOC.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Anurag Singh (786070)
 * @date 31-12-2020
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Message {

    private String message;
}
