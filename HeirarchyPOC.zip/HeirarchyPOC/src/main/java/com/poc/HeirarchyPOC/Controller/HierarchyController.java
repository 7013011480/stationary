package com.poc.HeirarchyPOC.Controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.poc.HeirarchyPOC.TCUPService.TCUPUserService;
import com.poc.HeirarchyPOC.model.HierarchyStructure.TreeNode1;
import com.poc.HeirarchyPOC.model.Message;
import com.poc.HeirarchyPOC.model.TCUPCatalogResponseModel;
import com.poc.HeirarchyPOC.model.TCUPFile;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/data-corner")
public class HierarchyController {

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@Autowired
	private TCUPUserService tcupDir;

	
	 @ApiResponse(responseCode = "500", description = "Please try after some time", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = Message.class)) })

	@RequestMapping(value = "/mydata/heirarchy/get/all", method = RequestMethod.POST, produces = "application/json")

	public ResponseEntity<?> getHierarchyForMyDataTab(@RequestHeader("apiKey") String apiKey,
			@RequestParam String metadata) {
		LOG.info("inside getHeirarcchyForMyDataTab\n");
		TCUPCatalogResponseModel model = new TCUPCatalogResponseModel();

		TreeNode1 root = new TreeNode1("");
		
		if (null == apiKey) {
			return new ResponseEntity<>(new Message("apiKey is missing"), HttpStatus.BAD_REQUEST);
		} else {

			List<String> metadataList = Arrays.asList(metadata.split(","));
			System.out.println(metadataList);

			 model = tcupDir.getCatalogData(apiKey,metadataList.get(0)); 
			 
			 
			 List<TCUPFile> file=model.getResult();
			 for(TCUPFile f: file)  { 
			 String str=f.getMetadata();
			 str="{\"" + str + "\"}"; 
			 str = str.replace("=", "\":\""); 
			 str = str.replace(",", "\",\""); 
			 
			 JSONObject json = new JSONObject(str);
			 
			 Map<String,String> map= new TreeMap<String,String>();
			 for(String s:metadataList)
			 {
			try {
			 map.put(s, json.get(s).toString());
				 }
			catch(Exception e)
			{break;}
			 }
			 
			 TreeNode1 temp_root=root;
		     
			 for(String key:map.keySet())
		       {
		    	   temp_root=insert(temp_root,key,map.get(key));
		       }
			 }
		    }
		    

			LOG.debug("catalog response retrieved \n");

			return new ResponseEntity<>(root, HttpStatus.OK);
		}
	 
	 
	 
	 @ApiResponse(responseCode = "500", description = "Please try after some time", content = {
				@Content(mediaType = "application/json", schema = @Schema(implementation = Message.class)) })

		@RequestMapping(value = "/get/Files", method = RequestMethod.POST, produces = "application/json")

		public ResponseEntity<?> getFiles(@RequestHeader("apiKey") String apiKey,
				@RequestParam String metadata) {
			LOG.info("inside getFilesForMyDataTab\n");
			TCUPCatalogResponseModel model = null;

			
			if (null == apiKey) {
				return new ResponseEntity<>(new Message("apiKey is missing"), HttpStatus.BAD_REQUEST);
			} else {

				 model = tcupDir.getCatalogData(apiKey,metadata); 
				 
//				 List<TCUPFile> files=model.getResult();
							    

				LOG.debug("catalog response retrieved \n");

				return new ResponseEntity<>(model, HttpStatus.OK);
			}
	 }
		 


	 public static TreeNode1 insert(TreeNode1 root,String key, String val)
	    {
		 for(TreeNode1 t:root.getHierarchy())
		 {
			 if(t.getValue().equals(val)) 
			 {
				 return t;
			 }
		 }
		 if(root.data == null)
	        root.hierarchy.add(new TreeNode1(val, key, "", ""));
		 else
			 root.hierarchy.add(new TreeNode1(val, key, root.data.getPath(), root.data.getMetadata())); 
			return root.hierarchy.get(root.getHierarchy().size()-1);
	    }
	 
}
