package com.poc.HeirarchyPOC.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TCUPFile {

    private String directory;

    @JsonProperty("file-uri")
    private String fileUri;

    @JsonProperty("created-on")
    private String createdTime;

    @JsonProperty("external-to-dls")
    private boolean externalToDLS;

    @JsonProperty("size-bytes")
    private long sizeBytes;

    @JsonProperty("transfer-success")
    private boolean transferSuccess;

    private boolean deleted;

    @JsonProperty("meta-data")
    private String metadata;

    @JsonProperty("own-file")
    private boolean ownFile;

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public boolean isOwnFile() {
        return ownFile;
    }

    public void setOwnFile(boolean ownFile) {
        this.ownFile = ownFile;
    }

//    public String getSavepoint() {
//        return savepoint;
//    }
//
//    public void setSavepoint(String savepoint) {
//        this.savepoint = savepoint;
//    }

    public String getFileUri() {
        return fileUri;
    }

    public void setFileUri(String fileUri) {
        this.fileUri = fileUri;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public boolean isExternalToDLS() {
        return externalToDLS;
    }

    public void setExternalToDLS(boolean externalToDLS) {
        this.externalToDLS = externalToDLS;
    }

    public long getSizeBytes() {
        return sizeBytes;
    }

    public void setSizeBytes(long sizeBytes) {
        this.sizeBytes = sizeBytes;
    }

    public boolean isTransferSuccess() {
        return transferSuccess;
    }

    public void setTransferSuccess(boolean transferSuccess) {
        this.transferSuccess = transferSuccess;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public String getExtension() {
        String extension = null;
        if (fileUri.contains(".")) {
            extension = fileUri.substring(fileUri.lastIndexOf(".") + 1, fileUri.length());
        }
        return extension;
    }

    public String getFileName() {
        String fileName = "";
        if (fileUri.contains(".")) {
            fileName = fileUri.substring(fileUri.lastIndexOf("/") + 1, fileUri.lastIndexOf("."));
        } else {
            fileName = fileUri.substring(fileUri.lastIndexOf("/") + 1, fileUri.length());
        }
        return fileName;
    }

    @Override
    public String toString() {
        return "TCUPFile{" + " directory=" + directory + ", fileUri=" + fileUri + ", createdTime=" + createdTime + ", externalToDLS=" + externalToDLS + ", sizeBytes=" + sizeBytes + ", transferAccess=" + transferSuccess + ", deleted=" + deleted + ", metadata=" + metadata + ", ownFile=" + ownFile + '}';
    }

}
