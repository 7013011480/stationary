package com.poc.HeirarchyPOC.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TCUPCatalogResponseModel {

    private String page;
    private int count;
    private List<TCUPFile> result;

}
