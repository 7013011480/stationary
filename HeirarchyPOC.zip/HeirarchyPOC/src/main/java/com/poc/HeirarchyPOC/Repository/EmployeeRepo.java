package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

}
