/**
 *
 * Copyright (c) "TCS Genomics Lab Foundation Platform Project"
 * TATA Consultancy Services [https://www.tcs.com/]
 *
 */
package com.poc.HeirarchyPOC.configuration;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

/**
 *
 * @author Anurag Singh (786070)
 * @date 24-02-2021
 */
@Configuration
public class AppConfiguration {

    @Bean
    public RestTemplate getRestTemplate(RestTemplateBuilder builder) {
        return builder
                .build();
    }

    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(-1);
        return multipartResolver;
    }
}
