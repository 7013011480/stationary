package com.poc.HeirarchyPOC.entity;


import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "order")
public class Order implements Serializable {


   @Id
   @Column(name = "order_id")
   private Integer orderId;

//   @NotNull
//   @Column(name = "user_id")
//   private Integer userId;

   @NotNull
   @Column(name = "purchase_value")
   private Integer purchaseValue;

   @NotNull
   @Column(name = "biller_id")
   private Integer billerId;

   @NotNull
   @Column(name = "order_date")
   private ZonedDateTime orderDate; 

   @OneToMany(cascade=CascadeType.ALL)
   @JoinColumn(name="order_details_fk", referencedColumnName="orderId")
   private Set<OrderDetails> orderDetails;
   
   @OneToOne(cascade=CascadeType.ALL)
   @JoinColumn(name="order_biller_fk", referencedColumnName="orderId")
   private Employee employee;

}
