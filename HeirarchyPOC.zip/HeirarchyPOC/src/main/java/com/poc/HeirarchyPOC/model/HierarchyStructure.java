package com.poc.HeirarchyPOC.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

public class HierarchyStructure {

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class TreeNode1{
        
//    	public String path;
    	public String key;
    	public String value;
//        public String metadata;
    	public HierarchyData data;
        public List<TreeNode1> hierarchy = new LinkedList<>();

        public TreeNode1(String data){
            value = data;
        }
        

        public TreeNode1(String val, String key, String path, String metadata){
            this.value = val;
            this.key = key;
            
            if(path !=null) this.data.path = path+"/"+key;
            else this.data.path = "/"+key;
            
            if(metadata!=null)  this.data.metadata = metadata + "&" + key + "="+ "'"+ value +"'";
            else this.data.metadata = key + "="+ "'"+ value +"'";
        }
        
        public TreeNode1(String data,List<TreeNode1> child){
            value = data;
            hierarchy = child;
        }
    }
}
