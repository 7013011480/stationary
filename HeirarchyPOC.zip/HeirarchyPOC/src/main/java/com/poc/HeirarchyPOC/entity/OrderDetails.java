package com.poc.HeirarchyPOC.entity;

import java.io.Serializable;
import java.time.ZonedDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orderDetails")
public class OrderDetails implements Serializable {


   @Id
   @Column(name = "order_id")
   private Integer orderId;

   @NotNull
   @Column(name = "object_id")
   private Integer objectId;

   @NotNull
   @Column(name = "quantity")
   private Integer quantity;

   @Column(name = "order_date")
   private ZonedDateTime orderDate; 

}
