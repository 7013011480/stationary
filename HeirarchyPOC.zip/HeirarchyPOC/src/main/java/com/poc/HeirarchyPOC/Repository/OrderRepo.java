package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.Order;

public interface OrderRepo extends JpaRepository<Order, Integer>{

}
