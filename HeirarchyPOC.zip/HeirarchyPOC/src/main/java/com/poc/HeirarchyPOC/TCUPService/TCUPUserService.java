/**
 *
 * Copyright (c) "TCS Genomics Lab Foundation Platform Project"
 * TATA Consultancy Services [https://www.tcs.com/]
 *
 */
package com.poc.HeirarchyPOC.TCUPService;


import com.poc.HeirarchyPOC.model.TCUPCatalogResponseModel;

/**
 *
 * @author Sunil Gedela (786070)
 * @date 19-10-2022
 */
public interface TCUPUserService {

	public TCUPCatalogResponseModel getCatalogData(String apiKey,String key);

}
