package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {

}
