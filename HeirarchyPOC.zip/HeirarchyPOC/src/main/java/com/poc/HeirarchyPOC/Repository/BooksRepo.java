package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.Books;

public interface BooksRepo extends JpaRepository<Books, Integer> {

}
