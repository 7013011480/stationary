package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.ObjectCategory;

public interface ObjectCategoryRepo extends JpaRepository<ObjectCategory, Integer> {

}
