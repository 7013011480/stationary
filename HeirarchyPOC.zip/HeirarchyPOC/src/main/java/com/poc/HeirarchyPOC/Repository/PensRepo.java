package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.Pens;

public interface PensRepo extends JpaRepository<Pens, Integer>{

}
