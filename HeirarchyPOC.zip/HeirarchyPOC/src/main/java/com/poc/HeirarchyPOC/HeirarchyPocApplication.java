package com.poc.HeirarchyPOC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeirarchyPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeirarchyPocApplication.class, args);
	}

}
