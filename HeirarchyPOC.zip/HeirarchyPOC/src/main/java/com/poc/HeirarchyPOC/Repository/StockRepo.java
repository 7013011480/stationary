package com.poc.HeirarchyPOC.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.HeirarchyPOC.entity.Stock;

public interface StockRepo extends JpaRepository<Stock, Integer> {

}
