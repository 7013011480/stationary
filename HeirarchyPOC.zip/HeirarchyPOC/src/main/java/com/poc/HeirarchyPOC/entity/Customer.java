package com.poc.HeirarchyPOC.entity;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "customer")
public class Customer implements Serializable {


   @Id
   @Column(name = "customer_id")
   private Integer customerId;

   @NotNull
   @Column(name = "user_name")
   private String userName;

   @NotNull
   @Column(name = "password")
   private String password;

   @NotNull
   @Column(name = "user_type")
   private String userType; //USER or ADMIN

   @Column(name = "mobile_no")
   private String mobileNo;

   @Column(name = "email")
   private String email;

   @Column(name = "address")
   private String address;

   @NotNull
   @Column(name = "created_date")
   private ZonedDateTime createdDate; 
   
   @OneToMany(cascade=CascadeType.ALL)
   @JoinColumn(name="cust_order_fk", referencedColumnName="customerId")
   private Set<Order> order;

}
