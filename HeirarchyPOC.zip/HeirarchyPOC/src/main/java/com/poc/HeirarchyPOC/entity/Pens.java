package com.poc.HeirarchyPOC.entity;
import java.io.Serializable;
import java.time.ZonedDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pens")
public class Pens implements Serializable {


   @Id
   @Column(name = "object_id")
   private Integer objectId;

   @NotNull
   @Column(name = "object_category_id")
   private Integer objectCategoryId;
   
   @NotNull
   @Column(name = "price")
   private Integer price;
   
   @NotBlank
   @Column(name = "color")
   private String color;
   
   @Column(name = "brand")
   private String brand;
   
   @Column(name = "created_date")
   private ZonedDateTime createdDate; 

}
