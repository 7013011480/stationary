/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.poc.HeirarchyPOC.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author Anurag Singh (786070)
 * @date 04-12-2020
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "dc")
public class ConstantEndpoints {

    private String scheme;
    private String s_scheme;
    private String tcup_host;
    private String TCUP_BASE_URL;
    private String TCUP_CATALOG_ENDPOINT;
    private String TCUP_CATALOG_DIRECTORY_ENDPOINT;
    private String TCUP_FILE_ENDPOINT;
    private String TCUP_FILE_LINK_ENDPOINT;
    private String TCUP_MULTIPLE_FILE_LINK_ENDPOINT;
    private String TCUP_DIRECTORY_ENDPOINT;
    private String TCUP_USER_DETAILS;
    private String get_project_details;
    private String pm_ms;
    private String pm_host;
    private String secretKey;
}
